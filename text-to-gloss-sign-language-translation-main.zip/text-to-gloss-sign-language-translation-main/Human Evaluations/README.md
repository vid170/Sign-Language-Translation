# Sign_language_human_evaluation

This repository is built for human evaluation of sign language translation using Stremlit. Specific instructions can be found under perspective folder.
